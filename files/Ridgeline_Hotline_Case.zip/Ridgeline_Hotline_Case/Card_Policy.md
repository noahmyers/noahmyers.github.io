# Ridgeline Materials, Inc. - Purchasing Card Policy (excerpt)
Effective October 1, 2025. Fictional company, created for training.

1. **Business use only.** Personal purchases are prohibited, even if the cardholder intends to repay them.
2. **Single-transaction limit: $5,000.** Splitting a purchase to stay under the limit is prohibited. Requests to exceed the limit go through the Pre-Approval process and must be approved *before* purchase.
3. **Gift cards, prepaid cards, and cash equivalents are prohibited** unless the CFO approves a written exception in advance.
4. **Consumer electronics, entertainment items, furniture, and appliances require pre-approval** from the cardholder's department head (see Pre-Approvals Log).
5. **Ship-to.** Items ship to a company location. Ship-to-home requires pre-approval.
6. **Business purpose.** Cardholders record a business purpose for every transaction. Statements such as "pre-approved" must match an entry in the Pre-Approvals Log.
7. **Standard equipment.** Where a company standard exists (see Equipment Standards), cardholders buy the standard item.
8. **Review.** Supervisors review cardholder statements monthly. Internal Audit performs periodic reviews.
