# Ridgeline Materials - Company Holidays, FY2026 (offices and plant closed)
- Thursday-Friday, November 27-28, 2025: Thanksgiving
- Wednesday-Thursday, December 24-25, 2025: Christmas Eve and Christmas Day
- Thursday, January 1, 2026: New Year's Day
- Monday, May 25, 2026: Memorial Day
- Friday, July 3, 2026: Independence Day (observed)
- Monday, September 7, 2026: Labor Day

Weekend and holiday work requires a supervisor-approved call-in (see badge records).
