# Ridgeline Materials - Equipment Standards (excerpt)
Maintained by IT and EHS. Buy the standard item unless a pre-approval says otherwise.

## IT (owner: Sam Patel, IT Director)
- **Headsets, help desk and customer service:** Jabra Evolve2 65 UC (bulk purchase Dec 2025).
- **Headsets, executives:** Jabra Evolve2 85, ordered by IT on request.
- **Conference rooms:** Logitech Rally Bar systems. Consumer streaming devices (Apple TV, Roku, Chromecast) are not permitted on the corporate network.
- **Site photos and inspections:** company-issued rugged iPads.
- **Workstations:** Dell Latitude laptops and Dell 27in monitors. Ridgeline has no in-house CAD users; design work is outsourced, so no GPU workstation upgrades are planned.
- **Mobile device testing:** IT tests with company-owned phones only; no personal accessories.

## EHS (owner: Sarah Lindqvist, EHS Manager)
- **Hearing protection:** issued by EHS. Approved models: 3M WorkTunes Connect, 3M Peltor. Consumer headphones and earbuds are *not* approved hearing protection.
- **Emergency and first-aid kits:** stocked by Cintas under contract. Do not purchase separately.
- **Drones:** not permitted on company property without an FAA Part 107-certified operator and EHS/Risk approval. Roof inspections are performed by Summit Roofing.
- **Hydration:** water stations and coolers supplied under the Costco Business bottled-water order.
